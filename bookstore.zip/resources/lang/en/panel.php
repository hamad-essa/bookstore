<?php

return [
    'site_title' => 'Bookstore Management System',

];
