<?php

return [
    'site_title' => 'نظام إدارة الكُتب',

];
